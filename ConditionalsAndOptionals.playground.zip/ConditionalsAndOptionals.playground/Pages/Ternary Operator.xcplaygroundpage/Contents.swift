/*:
 ## Ternary Operator
 
 Refactor the code below so that `largest` is declared and assigned to in one line using the ternary operator.
 */
let number1 = 14
let number2 = 25
let number1Largest = number1 > number2
let largest = (number1Largest ? number1 : number2)
print(largest)
//: [Previous](@previous)  |  page 7 of 9  |  [Next: Optionals](@next)
